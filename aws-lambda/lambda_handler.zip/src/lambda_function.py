import json
import boto3
import ast

def lambda_handler(event, context):
    """
    Lambda function to invoke SageMaker endpoint for diabetes prediction.
    """
    # SageMaker runtime client
    sagemaker_runtime = boto3.client('sagemaker-runtime', region_name='us-east-2')
    
    # SageMaker endpoint name
    # Old: sagemaker-xgboost-2024-11-28-08-54-34-142
    endpoint_name = "sagemaker-xgboost-2024-11-29-03-15-17-038"
    

    # Example input for the model
    # Replace with your specific payload format
    #input_data = {
    #    "data": [[1, 0, 5.7, 0, 110, 80, 32, 15.0, 28.0, 0.6, 45, 1, 0, 0]]
    #}
    #nput_data = '1, 0, 5.7, 0, 110, 80, 32, 15.0, 28.0, 0.6, 45, 1, 0, 0'
    #{'x1':1, 'x2':0, 'x3':5.7, 'x4':0, 'x5':110, 'x6':80, 'x7':32, 'x8':15.0, 'x9':28.0, 'x10':0.6, 'x11':45, 'x12':1,'x13':0, 'x14':0}
    input_data = '{},{},{},{},{},{},{},{},{},{},{},{},{},{}'.format(ast.literal_eval(event['body'])['x1'],
    ast.literal_eval(event['body'])['x2'],
    ast.literal_eval(event['body'])['x3'],
    ast.literal_eval(event['body'])['x4'],
    ast.literal_eval(event['body'])['x5'],
    ast.literal_eval(event['body'])['x6'],
    ast.literal_eval(event['body'])['x7'],
    ast.literal_eval(event['body'])['x8'],
    ast.literal_eval(event['body'])['x9'],
    ast.literal_eval(event['body'])['x10'],
    ast.literal_eval(event['body'])['x11'],
    ast.literal_eval(event['body'])['x12'],
    ast.literal_eval(event['body'])['x13'],
    ast.literal_eval(event['body'])['x14'])

    try:
        # Invoke the SageMaker endpoint
        response = sagemaker_runtime.invoke_endpoint(
            EndpointName=endpoint_name,
            ContentType="text/csv",  # Specify the format of your input
            #Body=json.dumps(input_data)      # Convert the input to JSON string
            Body=input_data
        )
        
        # Decode the response
        prediction = response['Body'].read().decode('utf-8')
        print(prediction)

        return {
            "statusCode": 200,
            "body": json.loads(prediction)  # Convert the prediction to JSON
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": f"Error invoking endpoint: {str(e)}"
        }

